#nfs client side
import os

usr = raw_input("Enter your username : ")

#discovery not required. iqn created same as the name of user is

#login
ec=os.system("iscsiadm --mode node --targetname "+ usr +" --portal 192.168.91.130:3260 --login")
if ec==0:
	print "Storage attached to your system"
